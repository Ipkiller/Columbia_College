#Student ID of the developers

"""
Student ID's
814994
815290
815203
"""

# An empty inventory
inventory={}

"""Functions of different usage to add,and remove the items and to display the inventory data"""

#Function to add data in the inventory
def add():
    try:
        #collecting data from user
        item_name=collector[2]
        quantity=int(collector[1])

        #if item is already in the inventory then, it does not need to insert same item twice
        if item_name in inventory.keys():
            inventory[item_name]+=quantity
            menu()
            return f"{item_name.capitalize()} ({quantity}) has been added in the Inventory"
        else:
            inventory.update({item_name:quantity})
            menu()
            return f"{item_name.capitalize()} ({quantity}) has been added in the Inventory"

    except:
        #invalid input
        return "Invaild input\nplease type 'add <quantity> <item name> "
    
#Function to remove data from the inventory
def remove():
    try:
        #collecting data from user
        item_name=collector[2]
        quantity=int(collector[1])

        # if the item exists in the inventory.
        if item_name in inventory.keys():
            inventory[item_name]-=quantity
            if inventory[item_name]<=0:
                inventory.pop(item_name)
            menu()
            return f"{item_name.capitalize()} ({quantity}) has been removed from the Inventory"

        # if the item does not exist in the inventory.
        else:
            menu()
            return f"{item_name.capitalize()} does not exist in the Inventory"

    except:
        #invalid input
        return "Invaild input\nplease type 'remove <quantity> <item name> "

#Function to display the data
def display():
    top=":  Item Name  :  Quantity  :\n"
    for keys in inventory.keys():
        top+=f":  {keys.capitalize()}{' '*(11-len(keys))}:"+f"  {inventory[keys]}{' '*(8-len(str(inventory[keys])))}  :\n"
    return top

# User menu interface
def menu():
    print("\nWelcome to the Inventory managment System!\n")
    print("1. Type 'add <quantity> <item name>'")
    print("2. Type 'remove <quantity> <item name>' to remove any data")
    print("3. Type 'Data' to display your data")
    print("4. Type 'Exit'\n")

menu()  #using menu function to print user menu.

#Loop to ask again and again unless user type exit
while True:
    #For input
    collector=str(input("Enter your choice: ")).lower()
    collector=collector.split()

    #To remove from the item, "Apples"-->"Apple"
    try:
        condition=collector[2].endswith("s")
        if condition:
            collector[2]=collector[2][:len(collector[2])-1]
    except:
        pass

    #Conditions to check what does user want
    if collector[0]=="add":
        print(add())

    elif collector[0]=="remove":
        print(remove())

    elif collector[0]=="data":
        print(display())

    elif collector[0]=="exit":
        print("You have been Exit the program")
        break

    else:
        menu()
        print("invaild input")