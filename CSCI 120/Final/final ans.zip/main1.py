# 814564
def find_longest_string(string_list):
    """
    Find the longest string in the given list.

    Parameters:
    - string_list (list): A list of strings.

    Returns:
    - str: The longest string in the list. If multiple strings have the same maximum length, return the first occurrence.
    """
    # WRITE YOUR CODE HERE
    longest = string_list[0]
    for string in string_list:
        if len(string) > len(longest):
            longest = string
    return longest
    # DO NOT CHANGE ANYTHING BELOW THIS


def main():
    # Initialize a list of strings for testing
    string_list = ["apple", "banana", "orange", "kiwi", "grape"]

    # Find the longest string in the list
    longest = find_longest_string(string_list)

    # Display the longest string
    print(f"\nOriginal List: {string_list}")
    print(f"Longest String: {longest}")


if __name__ == "__main__":
    main()
